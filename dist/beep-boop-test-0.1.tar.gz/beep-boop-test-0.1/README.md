# beepboop
says beep boop

to use:
- import, `import beeptest.booptest`
- use, `beeptest.booptest.beep(1)`
